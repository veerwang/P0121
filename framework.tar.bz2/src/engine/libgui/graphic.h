#ifndef GRAPHIC_H
#define GRAPHIC_H

/*
 * =====================================================================================
 *
 *       Filename:  graphic.h
 *
 *    Description:  Implementaion of GUI class 
 *
 *        Version:  1.0
 *        Created:  2014年09月13日 09时59分16秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  kevin (WangWei), kevin.wang2004@hotmail.com
 *   Organization:  GNU
 *
 * =====================================================================================
 */


class Graphic
{
	public:
		Graphic ();                             /* constructor */
		~Graphic ();                            /* destructor  */

	protected:

	private:

}; /* -----  end of class Graphic  ----- */

#endif /* GRAPHIC_H */
