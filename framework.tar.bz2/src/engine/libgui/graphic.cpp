/*
 * =====================================================================================
 *
 *       Filename:  graphic.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年09月13日 10时40分39秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  kevin (WangWei), kevin.wang2004@hotmail.com
 *   Organization:  GNU
 *
 * =====================================================================================
 */

#include "graphic.h"

Graphic::Graphic ()
{
}

Graphic::~Graphic ()
{
}
