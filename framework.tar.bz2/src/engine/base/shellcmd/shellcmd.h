#ifndef SHELLCMD_H
#define SHELLCMD_H

/*
 * =====================================================================================
 *
 *       Filename:  shellcmd.h
 *
 *    Description:  analyze the shell cmd 
 *
 *        Version:  1.0
 *        Created:  2014年09月13日 13时50分47秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  kevin (WangWei), kevin.wang2004@hotmail.com
 *   Organization:  GNU
 *
 * =====================================================================================
 */

class Shellcmd
{
	public:
		Shellcmd ();                             /* constructor */
		~Shellcmd ();                            /* destructor  */


	protected:

	private:

}; /* -----  end of class Shellcmd  ----- */

#endif /* SHELLCMD_H */
