/*
 * =====================================================================================
 *
 *       Filename:  shellcmd.cpp
 *
 *    Description:  implementaton of shellcmd 
 *
 *        Version:  1.0
 *        Created:  2014年09月13日 13时51分52秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  kevin (WangWei), kevin.wang2004@hotmail.com
 *   Organization:  GNU
 *
 * =====================================================================================
 */

#include "shellcmd.h"

Shellcmd::Shellcmd ()
{
}

Shellcmd::~Shellcmd ()
{
}

